/**
 * Genre page auto-load.
 *
 * Watches the loader at the bottom of the card list and appends the next page
 * of cards as soon as it scrolls into view, until the provider runs out.
 * Replaces the old Prev/Next pagination.
 */
(function () {
    'use strict';

    const loader = document.getElementById('kpLoadMore');
    const list = document.getElementById('kpGenreList');
    if (!loader || !list) return;

    const retry = document.getElementById('kpLoadRetry');
    const endpoint = loader.dataset.endpoint || './includes/genre_items.php';
    const genre = loader.dataset.genre || '';
    const sort = loader.dataset.sort || 'popular';
    const perPage = parseInt(loader.dataset.perPage || '24', 10);

    let page = Math.max(1, parseInt(loader.dataset.page || '1', 10));
    let hasNext = loader.dataset.hasNext === '1';
    let busy = false;

    function setState(state) {
        loader.classList.toggle('is-loading', state === 'loading');
        loader.classList.toggle('is-done', state === 'done');
        loader.classList.toggle('is-error', state === 'error');
    }

    function finish() {
        hasNext = false;
        loader.dataset.hasNext = '0';
        setState('done');
    }

    function nextUrl() {
        return endpoint
            + '?g=' + encodeURIComponent(genre)
            + '&sort=' + encodeURIComponent(sort)
            + '&page=' + page
            + '&limit=' + perPage;
    }

    /** Short pages leave the loader on screen — keep filling until it scrolls away. */
    function ensureFill() {
        if (!hasNext || busy) return;
        const rect = loader.getBoundingClientRect();
        if (rect.top < window.innerHeight + 400) load();
    }

    function load() {
        if (busy || !hasNext) return;
        busy = true;
        setState('loading');

        fetch(nextUrl(), { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then((r) => r.json())
            .then((data) => {
                if (!data || typeof data.html !== 'string') throw new Error('bad payload');

                if (data.html) list.insertAdjacentHTML('beforeend', data.html);

                if (data.has_next && data.count > 0) {
                    page = (parseInt(data.page, 10) || page) + 1;
                    setState('idle');
                } else {
                    finish();
                }
            })
            .catch(() => {
                setState('error');
            })
            .finally(() => {
                busy = false;
                if (hasNext) ensureFill();
            });
    }

    if (!hasNext) {
        finish();
    } else {
        setState('idle');

        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver((entries) => {
                if (entries.some((entry) => entry.isIntersecting)) load();
            }, { rootMargin: '400px 0px' });
            observer.observe(loader);
        } else {
            // No observer support: fall back to a scroll listener.
            window.addEventListener('scroll', () => {
                const rect = loader.getBoundingClientRect();
                if (rect.top < window.innerHeight + 400) load();
            }, { passive: true });
        }

        ensureFill();
    }

    if (retry) {
        retry.addEventListener('click', () => {
            setState('idle');
            load();
        });
    }
})();
